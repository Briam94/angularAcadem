import { DashboardComponent } from './components/dashboard/dashboard.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'inicio', pathMatch: 'full' },
  { path: 'inicio', component: DashboardComponent },
  {
    path: 'estudiantes',
    loadChildren: './modules/estudiante/estudiante/estudiante.module#EstudianteModule'
  },
  {
    path: 'profesores',
    loadChildren: './modules/profesor/profesor/profesor.module#ProfesorModule'
  },
  {
    path: 'mensualidades',
    loadChildren: './modules/mensualidad/mensualidad/mensualidad.module#MensualidadModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
