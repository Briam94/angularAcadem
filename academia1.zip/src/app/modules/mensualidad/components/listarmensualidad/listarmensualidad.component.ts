import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listarmensualidad',
  templateUrl: './listarmensualidad.component.html',
  styleUrls: ['./listarmensualidad.component.css']
})
export class ListarmensualidadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
