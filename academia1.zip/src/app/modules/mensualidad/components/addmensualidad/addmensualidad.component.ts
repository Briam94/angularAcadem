import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addmensualidad',
  templateUrl: './addmensualidad.component.html',
  styleUrls: ['./addmensualidad.component.css']
})
export class AddmensualidadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
