import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddmensualidadComponent } from './addmensualidad.component';

describe('AddmensualidadComponent', () => {
  let component: AddmensualidadComponent;
  let fixture: ComponentFixture<AddmensualidadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddmensualidadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddmensualidadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
