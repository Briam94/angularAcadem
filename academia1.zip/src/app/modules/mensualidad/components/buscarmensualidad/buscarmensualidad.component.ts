import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buscarmensualidad',
  templateUrl: './buscarmensualidad.component.html',
  styleUrls: ['./buscarmensualidad.component.css']
})
export class BuscarmensualidadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
