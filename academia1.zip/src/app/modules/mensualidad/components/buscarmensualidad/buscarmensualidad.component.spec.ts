import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuscarmensualidadComponent } from './buscarmensualidad.component';

describe('BuscarmensualidadComponent', () => {
  let component: BuscarmensualidadComponent;
  let fixture: ComponentFixture<BuscarmensualidadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuscarmensualidadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuscarmensualidadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
