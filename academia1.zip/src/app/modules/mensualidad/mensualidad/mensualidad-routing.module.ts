import { MensualidadComponent } from './mensualidad.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const rout: Routes = [
    { path: '', redirectTo: 'mensualidades', pathMatch: 'full' },
    { path: 'mensualidades', component: MensualidadComponent }
];

@NgModule({
    imports: [RouterModule.forChild(rout)],
    exports: [RouterModule]
})
export class MensualidadRoutingModule { }