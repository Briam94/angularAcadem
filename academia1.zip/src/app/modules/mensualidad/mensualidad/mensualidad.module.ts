import { MensualidadRoutingModule } from './mensualidad-routing.module';
import { AddmensualidadComponent } from './../components/addmensualidad/addmensualidad.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MensualidadComponent } from './mensualidad.component';

@NgModule({
  declarations: [
    MensualidadComponent,
    AddmensualidadComponent
  ],
  imports: [
    CommonModule,
    MensualidadRoutingModule
  ]
})
export class MensualidadModule { }
