import { ListarprofesorComponent } from './../components/listarprofesor/listarprofesor.component';
import { BuscarprofesorComponent } from './../components/buscarprofesor/buscarprofesor.component';
import { AddprofesorComponent } from './../components/addprofesor/addprofesor.component';
import { ProfesorRoutingModule } from './profesor-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfesorComponent } from './profesor.component';

@NgModule({
  declarations: [
    ProfesorComponent,
    AddprofesorComponent,
    BuscarprofesorComponent,
    ListarprofesorComponent
  ],
  imports: [
    CommonModule,
    ProfesorRoutingModule
  ]
})
export class ProfesorModule { }
