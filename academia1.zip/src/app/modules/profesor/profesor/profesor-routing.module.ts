import { ProfesorComponent } from './profesor.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const rout: Routes = [
    { path: '', redirectTo: 'profesores', pathMatch: 'full' },
    { path: 'profesores', component: ProfesorComponent }
];

@NgModule({
    imports: [RouterModule.forChild(rout)],
    exports: [RouterModule]
})
export class ProfesorRoutingModule { }