import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listarprofesor',
  templateUrl: './listarprofesor.component.html',
  styleUrls: ['./listarprofesor.component.css']
})
export class ListarprofesorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
