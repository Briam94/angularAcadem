import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListarprofesorComponent } from './listarprofesor.component';

describe('ListarprofesorComponent', () => {
  let component: ListarprofesorComponent;
  let fixture: ComponentFixture<ListarprofesorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListarprofesorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListarprofesorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
