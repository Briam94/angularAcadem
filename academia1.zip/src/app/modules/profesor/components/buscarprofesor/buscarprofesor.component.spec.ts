import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuscarprofesorComponent } from './buscarprofesor.component';

describe('BuscarprofesorComponent', () => {
  let component: BuscarprofesorComponent;
  let fixture: ComponentFixture<BuscarprofesorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuscarprofesorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuscarprofesorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
