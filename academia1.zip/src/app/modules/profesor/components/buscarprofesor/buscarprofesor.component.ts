import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buscarprofesor',
  templateUrl: './buscarprofesor.component.html',
  styleUrls: ['./buscarprofesor.component.css']
})
export class BuscarprofesorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
