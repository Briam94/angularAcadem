import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addprofesor',
  templateUrl: './addprofesor.component.html',
  styleUrls: ['./addprofesor.component.css']
})
export class AddprofesorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
