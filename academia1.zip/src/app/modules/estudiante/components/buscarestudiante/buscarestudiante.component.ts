import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buscarestudiante',
  templateUrl: './buscarestudiante.component.html',
  styleUrls: ['./buscarestudiante.component.css']
})
export class BuscarestudianteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
