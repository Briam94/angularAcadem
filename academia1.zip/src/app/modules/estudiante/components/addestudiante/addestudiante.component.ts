import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addestudiante',
  templateUrl: './addestudiante.component.html',
  styleUrls: ['./addestudiante.component.css']
})
export class AddestudianteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
