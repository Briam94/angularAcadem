import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listarestudiante',
  templateUrl: './listarestudiante.component.html',
  styleUrls: ['./listarestudiante.component.css']
})
export class ListarestudianteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
