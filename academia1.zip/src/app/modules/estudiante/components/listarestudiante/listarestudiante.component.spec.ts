import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListarestudianteComponent } from './listarestudiante.component';

describe('ListarestudianteComponent', () => {
  let component: ListarestudianteComponent;
  let fixture: ComponentFixture<ListarestudianteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListarestudianteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListarestudianteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
