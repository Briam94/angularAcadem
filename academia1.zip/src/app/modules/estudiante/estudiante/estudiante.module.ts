import { ListarestudianteComponent } from './../components/listarestudiante/listarestudiante.component';
import { BuscarestudianteComponent } from './../components/buscarestudiante/buscarestudiante.component';
import { AddestudianteComponent } from './../components/addestudiante/addestudiante.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EstudianteComponent } from './estudiante.component';
import { EstudianteRoutingModule } from './estudiante-routing.module';

@NgModule({
  declarations: [
    EstudianteComponent,
    AddestudianteComponent,
    BuscarestudianteComponent,
    ListarestudianteComponent
  ],
  imports: [
    CommonModule,
    EstudianteRoutingModule
  ]
})
export class EstudianteModule { }
