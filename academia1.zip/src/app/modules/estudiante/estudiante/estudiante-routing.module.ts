
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EstudianteComponent } from './estudiante.component';

const rout: Routes = [
    { path: '', redirectTo: 'estudiantes', pathMatch: 'full' },
    { path: 'estudiantes', component: EstudianteComponent }
];

@NgModule({
    imports: [RouterModule.forChild(rout)],
    exports: [RouterModule]
})
export class EstudianteRoutingModule { }